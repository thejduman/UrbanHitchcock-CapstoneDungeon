# UrbanHitchcock-CapstoneDungeon

This is a 2D exploration game that incorporates cybersecurity puzzles. Players can explore various areas, known as dungeons, and will be quizzed on cybersecurity topics as they progress these areas. The further the player gets in the game, the harder the questions will get. 