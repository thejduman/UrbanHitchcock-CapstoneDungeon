public interface IInteractable
{
    void Interact(Player player);
}
